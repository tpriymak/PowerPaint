
package tools;
/**
 * 
 * @author Timur
 * @version 11/20
 */
public class ActionConstants
{
  //gives the Selected key a string.
  /**
   * Selected key string.
   */

  public static final String SELECTED_KEY = "actionConstants.selected";
}
